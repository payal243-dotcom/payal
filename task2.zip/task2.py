exchange_rates={
     'USD_to_EUR':0.84,
     'GBP_to_CAD':1.73,
     'AUD_to_USD':0.66,
     'INR_to_USD':0.01,
     'JPY_to_CNY':0.04
}
amount = float(input("Enter the amount you want to convert: "))

from_currency = input("Convert from currency (e.g, USD): ").upper()

to_currency = input("Convert to currency (e.g, EUR): ").upper()

if from_currency == to_currency:

    print("You are converting the same currency.The amount remains unchanged.")

elif f'{from_currency}_to_{to_currency}'in exchange_rates:

    exchange_rate = exchange_rates[f'{from_currency}_to_{to_currency}']

    converted_amount=amount * exchange_rate

    print(f"{amount} {from_currency} is equal to {converted_amount} {to_currency}")

elif f'{to_currency}_to_{from_currency}'in exchange_rates:

    exchange_rate = 1/ exchange_rates[f'{to_currency}_to_{from_currency}'] 

    converted_amount=amount * exchange_rate
    
    print(f"{amount} {from_currency} is equal to {converted_amount} {to_currency}")


