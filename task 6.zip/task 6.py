import random
import math
def print_instructions():
    print("Welcome to Guess the Number!")
    print("Objective: Guess the number within a specified range.")
    print("How to play:")
    print("- You will be prompted to select a difficulty level or set a custom range.")
    print("- Try to guess a number in the fewest attempts possible.")
    print("- Based on your guesses, hints will be provided to assist you.")
    print("- Your score will be calculated based on the number of attempts taken.")
    print("Have fun and good luck!")

def settings_menu():
    print("\nSETTINGS MENU")
    print("1. Select Difficulty level")
    print("2. Set Custom range and Attempts")
    print("3. View leaderboard")
    print("4. Exit Settings")
    choice = input("Enter your choice (1-4): ")
    return choice

def get_difficulty_level():
    print("\nSelect a difficulty level:")
    print("1. Easy (Range: 1-50, Attempts: 10)")
    print("2. Medium (Range: 1-100, Attempts: 7)")
    print("3. Hard (Range: 1-200, Attempts: 5)")
    choice = input("Enter your choice (1-3): ")
    return choice

def set_custom_range():
    start = int(input("Enter the start of the range: "))
    end = int(input("Enter the end of the range: "))
    max_attempts = int(input("Enter the maximum number of attempts: "))
    while start >= end or max_attempts <= 0:
        print("Invalid input. Ensure start < end and attempts > 0.")
        start = int(input("Enter the start of the range: "))
        end = int(input("Enter the end of the range: "))
        max_attempts = int(input("Enter the maximum number of attempts: "))
    return start, end, max_attempts

def view_leaderboard(leaderboard):
    print("\nLEADERBOARD")
    print("Name \t\t Score")
    for entry in leaderboard:
        print(f"{entry['name']} \t\t {entry['score']}")

def provide_hint(number_to_guess, guess):
    hints = []
    if number_to_guess % 2 == 0:
        hints.append("Hint: The number is even.")
    else:
        hints.append("Hint: The number is odd.")
    if number_to_guess % guess == 0:
        hints.append(f"Hint: The number is divisible by {guess}.")
    else:
        hints.append(f"Hint: The number is not divisible by {guess}.")
    if is_prime(number_to_guess):
        hints.append("Hint: The number is prime.")
    else:
        hints.append("Hint: The number is not prime.")
    for hint in hints:
        print(hint)

def is_prime(num):
    if num <= 1:
        return False
    if num <= 3:
        return True
    if num % 2 == 0 or num % 3 == 0:
        return False
    i = 5
    while i * i <= num:
        if num % i == 0 or num % (i + 2) == 0:
            return False
        i += 6
    return True

def play_round(start, end, max_attempts):
    number_to_guess = random.randint(start, end)
    attempts = 0
    while attempts < max_attempts:
        guess = int(input(f"Guess the number between {start} and {end}: "))
        attempts += 1
        if guess == number_to_guess:
            print(f"Congratulations! You guessed the number {number_to_guess} in {attempts} attempts.")
            return attempts
        elif guess < number_to_guess:
            print("Try a higher number.")
        else:
            print("Try a lower number.")
    print(f"Sorry, you did not guess the number. It was {number_to_guess}.")
    return attempts

def guess_the_number():
    print_instructions()
    leaderboard = []
    while True:
        choice = settings_menu()
        if choice == '1':
            difficulty_choice = get_difficulty_level()
            if difficulty_choice == '1':
                start, end, max_attempts = 1, 50, 10
            elif difficulty_choice == '2':
                start, end, max_attempts = 1, 100, 7
            elif difficulty_choice == '3':
                start, end, max_attempts = 1, 200, 5
        elif choice == '2':
            start, end, max_attempts = set_custom_range()
        elif choice == '3':
            view_leaderboard(leaderboard)
            continue
        elif choice == '4':
            break
        else:
            print("Invalid choice. Please enter a number between 1 and 4.")
            continue
        
        score = play_round(start, end, max_attempts)
        
        player_name = input("Enter your name: ")
        leaderboard.append({'name': player_name, 'score': score})
        
        play_again = input("Do you want to play again? (yes/no): ")
        if play_again.lower() != 'yes':
            break
    
    print("\nThanks for playing!")

if __name__ == "__main__":
    guess_the_number()
