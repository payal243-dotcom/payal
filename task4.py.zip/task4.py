import requests

api_key = '82315298d0edc29f44f6a6d'

source_currency = input('Enter the source currency e.g. INR: ').upper()
amount = float(input('Enter the amount: '))
target_currency = input('Enter the target currency e.g. USD: ').upper()

url = f'https://v6.exchangerate-api.com/v6/823152e98d0edc29f44f6a6d/latest/USD'
print(f'Requesting data from: {url}')

response = requests.get(url)

if response.status_code == 200:
    data = response.json()
    if 'conversion_rates' in data:
        conversion_rates = data['conversion_rates']
        if target_currency in conversion_rates:
            exchange_rate = conversion_rates[target_currency]
            conversion_amount = amount * exchange_rate
            print(f'Converted amount is {conversion_amount} {target_currency}')
        else:
            print(f'Target currency "{target_currency}" is not found in conversion rates.')
    else:
        print('No conversion rates found in the response.')
else:
    print(f'Failed !')