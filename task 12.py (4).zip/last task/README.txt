#Spelly Game README
#Introduction
Spelly Game is a word-based game implemented in Python using the Tkinter library for the graphical user interface. The game involves a player and a computer opponent taking turns to come up with words that start with the last letter of the previous word.
GAMEPLAY:

The game starts with a random word selected from a list of 10,000 words.

The player is presented with a shuffled version of the word and must come up with a word that starts with the last letter of the previous word.

If the player's input is valid, their score is updated, and the computer opponent takes its turn.

The computer opponent selects a random word from the list that starts with the last letter of the previous word.

The game continues until the player or computer opponent cannot come up with a valid word.

FEATURES:

Word List: The game uses a list of 10,000 words obtained from https://www.mit.edu/~ecprice/wordlist.10000.

Shuffled Word Display: The current word is displayed in a shuffled format to make it more challenging for the player.

Hint Option: A hint button is provided that displays a generic hint message to help the player.
Score Display: The player's score is displayed in real-time.

TECHNICAL DETAILS:

Python Version: The game is implemented in Python 3.x.

Libraries Used: The game uses the following libraries:

requests for fetching the word list from the internet.

sqlite3 for creating a local database to store the word list.

tkinter for creating the graphical user interface.

random for generating random words and shuffling the word display.

time for introducing a delay between the computer opponent's turns.

Running the Game:
To run the game, simply execute the Python script using a Python interpreter. The game will launch in a new window, and you can start playing by entering a word in the input field.