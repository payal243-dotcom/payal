import numpy as np
ages_list = [23,45,34,25,42,36,29,31]
ages_array = np.array(ages_list)
print("NumPy array from list of ages:", ages_array)
zeros_array = np.zeros((3,4))
ones_array = np.ones((2,5))
print("Zeros Array:\n", zeros_array)
print("Ones Array:\n", ones_array)
random_array = np.random.rand(4,3)
print("random Array:\n", random_array)

#TASK2
arr1 = np.random.randint(1,10 , size=(2,3))
arr2 = np.random.randint(1,10 , size=(2,3))
addition = arr1 + arr2
subtraction = arr1 - arr2
multiplication = arr1 * arr2
division = arr1 / arr2
print("addition:\n", addition)
print("subtracction:\n", subtraction)
print("multiplication:\n", multiplication)
print("division:\n", division)
sum_arr1 = np.sum(arr1)
mean_arr1 = np.mean(arr1)
min_arr1 = np.min(arr1)
max_arr1 = np.max(arr1)
print("Sum of arr1:",sum_arr1)
print("Mean of arr1:",mean_arr1)
print("Minimum value of arr1:",min_arr1)
print("Maximum value of arr1:",max_arr1)
reshaped_arr1 = arr1.reshape(3,2)
print("reshaped arr1:\n", reshaped_arr1)

#task3
arr1[0, 1]=20
print("Modified arr1:\n",arr1)
elements_greater_than_5 = arr1[arr1 > 5]
print("Elements of arr1 greater than 5:",elements_greater_than_5 )

#task4
arr3 = np.array([[1],[2],[3]])
arr4 = np.array([[4, 5, 6]])
broadcasted_addition = arr3 + arr4
print("broadcasted addition result:\n", broadcasted_addition)
multiplied_arr3 = arr3 * 10
print("multiplied arr3 by 10:\n", multiplied_arr3)

#task5
concatenated_array = np.concatenate((arr1, arr2), axis=1)
print("Concatenated array along axis 0:\n", concatenated_array)
split_arrays = np.split(concatenated_array, 2, axis=1)
print("Split arrays along axis 1:\n", split_arrays)

#task6
mat1 = np.random.randint(1, 10, size=(2, 3))
mat2 = np.random.randint(1, 10, size=(3, 2))

dot_product = np.dot(mat1, mat2)
print("Dot product of mat1 and mat2:\n", dot_product)

square_matrix = np.array([[1, 2], [3, 4]])
eigenvalues, eigenvectors = np.linalg.eig(square_matrix)

print("Eigenvalues of the square matrix:\n", eigenvalues)
print("Eigenvectors of the square matrix:\n", eigenvectors)

matrix_3x3 = np.random.rand(3, 3)
inverse_matrix_3x3 = np.linalg.inv(matrix_3x3)

print("Original 3x3 matrix:\n", matrix_3x3)
print("Inverse of the 3x3 matrix:\n", inverse_matrix_3x3)






 
















































































































