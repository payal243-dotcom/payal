import os
import shutil
def organize_downloads_folder(folder_path):
    file_types = {
        'images': ['.jpg', '.jpeg', '.png', '.gif'],
        'documents': ['.pdf', '.docx', '.xlsx', '.pptx', '.txt'],
        'videos': ['.mp4', '.avi', '.mov', '.mkv']
    }
    for folder in file_types.keys():
        folder_path = os.path.join(folder_path, folder)
        os.makedirs(folder_path, exist_ok=True)
    files = os.listdir(folder_path)

    for file in files:
        if os.path.isfile(os.path.join(folder_path, file)):
            file_extension = os.path.splitext(file)[1].lower()
            
            category = 'desktop'
            for key, extensions in file_types.items():
                if file_extension in extensions:
                    category = key
                    break
            destination_folder = os.path.join(folder_path, category)
            shutil.move(os.path.join(folder_path, file), os.path.join(destination_folder, file))

    print("Files have been organized successfully!")
if __name__ == "__main__":
    downloads_folder = '/path/to/your/downloads/folder' 
    organize_downloads_folder(downloads_folder)
